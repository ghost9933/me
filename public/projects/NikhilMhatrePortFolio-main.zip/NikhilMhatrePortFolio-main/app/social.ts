export default [
  { title: "email", url: "mailto:mhatrenikhil36@gmail.com" },
  { title: "twitter", url: "" },
  { title: "instagram", url: "" },
  { title: "github", url: "https://github.com/ghost9933" },
  { title: "linkedin", url: "https://www.linkedin.com/in/nikhil-mhatre-365785191" },
];
